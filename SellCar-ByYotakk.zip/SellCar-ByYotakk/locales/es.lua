Locales['es'] = {
    ['alreadyTesting'] = "Ya estas testeando otro vehiculo",
    ['notification_1'] = "<font color='green'>Test de Conduccion del Vehiculo</font><br>Te quedan <font color='red'>",
    ['notification_2'] = "</font> segundos",
    ['payMethod'] = "¿Con metodo que deseas pagar?",
    ['insertPlate'] = "Inserta la Matricula [8 CARACTERES MAX]",
    ['insertedPlate'] = "Matricula personalizada insertada --> ",
    ['plateAlreadyExists'] = "Esa matricula ya existe",
    ['notPersPlate'] = "En esta ciudad no estan permitidas las matriculas personalizadas",
    ['vehReceived'] = "Vehiculo ~g~Entregado~w~.",
    ['verLicense'] = "Verificando Licencia...",
    ['notHaveLicense'] = "No tienes la licencia de conducir",
    ['getCarPlate'] = "obtuvo un vehiculo con matricula",
    ['getVehicle_1'] = "Has recibido un vehiculo -- Matricula: ",
    ['getVehicle_2'] = " / Modelo: "
}